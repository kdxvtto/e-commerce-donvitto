import {body, validationResult} from 'express-validator';

// Validasi input order (tambah/update)
const addOrderValidation = [
    body('orderNumber').isString().withMessage('Order number must be a string'),
    body('items').isArray().withMessage('Items must be an array'),
    body('totalAmount').isNumeric().withMessage('Total amount must be a number'),
    body('status').isString().withMessage('Status must be a string'),
]

const updateOrderValidation = [
    body('orderNumber').isString().withMessage('Order number must be a string'),
    body('items').isArray().withMessage('Items must be an array'),
    body('totalAmount').isNumeric().withMessage('Total amount must be a number'),
    body('status').isString().withMessage('Status must be a string'),
]

// Kirim error validasi jika ada
const validate = (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }
    next();
};

export {
    addOrderValidation,
    updateOrderValidation,
    validate
}
