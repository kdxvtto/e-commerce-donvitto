import { Link } from "react-router-dom";

// Kerangka halaman login/register
export const AuthLayout = ({ type = "login", children, title }) => {

  const isLogin = type.toLowerCase() === "login";

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-50 px-4">
      <div className="w-full max-w-md bg-white shadow-md rounded-lg p-6">

        {/* Title */}
        {title && (
          <h1 className="text-2xl font-semibold text-gray-800 mb-2 text-center">
            {title}
          </h1>
        )}

        {/* Subtitle fix — sekarang subtitle tidak pakai type lagi */}
        <p className="text-gray-500 text-sm text-center mb-6">
          {isLogin ? "Login to your account" : "Create your account"}
        </p>

        {children}

        <p className="text-sm mt-5 text-center">
          {isLogin ? "Don't have an account? " : "Have an account? "}
          <Link 
            to={isLogin ? "/register" : "/login"} 
            className="font-bold text-blue-500"
          >
            {isLogin ? "Sign Up" : "Login"}
          </Link>
        </p>

      </div>
    </div>
  );
};
