import { InputForm } from "../elements/Input/Index";
import { Button } from "../elements/Button";
import { useRef } from "react";

// Form registrasi sederhana (masih template dan reuse nama FormLogin)
export const FormLogin = () => {
    const usernameRef = useRef(null);
    return (
        <form>
            <InputForm label="Email" type="email" placeholder="Enter your email" name="email" ref={usernameRef}/>
            <InputForm label="Password" type="password" placeholder="Enter your password" name="password"/>
            <Button variant ="bg-blue-500 w-full" type="submit">Login</Button>
        </form>
    )
}
