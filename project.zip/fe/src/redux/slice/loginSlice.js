import {createSlice, createAsyncThunk} from "@reduxjs/toolkit";
import { api } from "../../lib/api";


// Ambil token dari localStorage jika ada (agar sesi tetap hidup saat refresh)
const tokenFromStorage = localStorage.getItem("token") || null;
if(tokenFromStorage){
    api.defaults.headers.common["Authorization"] = `Bearer ${tokenFromStorage}`;
}

// Thunk untuk login user dan menyimpan token
export const loginUser = createAsyncThunk(
    "auth/login",
    async({email, password}, { rejectWithValue }) => {
        try{
            const res = await api.post("/auth/login", {email, password});
            const token = res.data?.token; // ini yang akan menjadi payload
            if(!token){
                return rejectWithValue("Token not found");
            }
            return {token};
        }catch(err){
            const msg = err.response?.data?.message || "Login gagal, periksa email/password";
            return rejectWithValue(msg);
        }
    }
)

// State awal auth
const initialState = {
    token : tokenFromStorage,
    isAuthenticated : !!tokenFromStorage,
    loading : false,
    errors : null
}

// Slice auth: handle login/logout
const authSlice = createSlice({
    name : "auht",
    initialState,
    reducers :{
        // Keluar dari sesi dan bersihkan token
        logout(state){
            state.token = null;
            state.loading = false;
            state.errors = null;
            state.isAuthenticated = false;
        
        localStorage.removeItem("token");
        delete api.defaults.headers.common["Authorization"]
        }
    },
    // Handle state untuk siklus hidup login
    extraReducers : (builder) => {
        builder
        .addCase(loginUser.pending, (state) =>{
            state.loading = true;
            state.errors = null;
            state.isAuthenticated = false;
        })
        .addCase(loginUser.fulfilled, (state, action) => {
            state.loading = false;
            state.token = action.payload.token; //ambil dari loginUser
            state.isAuthenticated = true;
            state.errors = null;

            localStorage.setItem("token", action.payload.token);
            api.defaults.headers.common["Authorization"] = `Bearer ${action.payload.token}`;
        })
        .addCase(loginUser.rejected, (state, action) => {
            state.loading = false;
            state.isAuthenticated = false;
            state.errors = action.payload || "Login gagal, periksa email/password";
        })
    }
})

export const {logout} = authSlice.actions;
export const selectAuth = (state) => state.auth;
export default authSlice.reducer;
